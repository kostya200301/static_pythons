#include <Python.h>

int main(int argc, char *argv[]) {
    Py_Initialize();
    PyRun_SimpleString("print('Привет из встроенного Python 3.9!')");
    Py_Finalize();
    return 0;
}

